// UsersIndex.jsx
import React, { useMemo, useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { Link, useForm, usePage } from "@inertiajs/react";
import AuthLayout from "@/Layouts/AuthLayout";

/* ---------- Portal util ---------- */
function Portal({ children }) {
  if (typeof document === "undefined") return null;
  return createPortal(children, document.body);
}

/* ---------- Avatar ---------- */
const avatar = (
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="12" fill="#F9A825" />
    <circle cx="12" cy="9" r="3.5" fill="#fff" />
    <path d="M4.5 19a7.5 7.5 0 0115 0v.5H4.5V19z" fill="#fff" />
  </svg>
);

const roleLabel = (r) => (r === 1 ? "Administrador" : r === 2 ? "Moderador" : "Leitor");

/* Helpers de CPF */
const unmask = (s) => (s || "").replace(/\D+/g, "");
const maskCpf = (v) => {
  const n = unmask(v).slice(0, 11);
  if (n.length <= 3) return n;
  if (n.length <= 6) return `${n.slice(0, 3)}.${n.slice(3)}`;
  if (n.length <= 9) return `${n.slice(0, 3)}.${n.slice(3, 6)}.${n.slice(6)}`;
  return `${n.slice(0, 3)}.${n.slice(3, 6)}.${n.slice(6, 9)}-${n.slice(9)}`;
};

/* Style helper do menu */
const menuItemStyle = {
  width: "100%",
  padding: "14px 18px",
  border: "none",
  backgroundColor: "transparent",
  textAlign: "left",
  cursor: "pointer",
  fontSize: "0.9rem",
  fontWeight: 500,
  color: "#333",
  borderBottom: "1px solid #F0F0F0",
};

export default function UsersIndex() {
  const { props } = usePage();
  const users = props.users ?? [];
  const canCreate = !!(props.can && props.can.create);

  /* Toast (3s) */
  const [toast, setToast] = useState(null);
  useEffect(() => {
    let t;
    if (props.flash?.success) {
      setToast({ text: props.flash.success, type: "ok" });
      t = setTimeout(() => setToast(null), 3000);
    } else if (props.flash?.error) {
      setToast({ text: props.flash.error, type: "err" });
      t = setTimeout(() => setToast(null), 3000);
    }
    return () => clearTimeout(t);
  }, [props.flash]);

  /* ===== Editar ===== */
  const [editing, setEditing] = useState(null);
  const [originalCpf, setOriginalCpf] = useState("");

  const editForm = useForm({
    id: null,
    name: "",
    cpf: "",
    email: "",
    data_nascimento: "",
    role: 3,
    password: "",
    password_confirmation: "",
  });

  const openEdit = (u) => {
    const raw = u.cpf_raw ? String(u.cpf_raw) : unmask(u.cpf);
    setOriginalCpf(raw);

    setEditing(u);
    editForm.setData({
      id: u.id,
      name: u.name,
      cpf: maskCpf(raw),
      email: u.email,
      data_nascimento: "",
      role: Number(u.role || 3),
      password: "",
      password_confirmation: "",
    });
  };

  const submitEdit = (e) => {
    e.preventDefault();
    editForm.transform((curr) => {
      const out = { ...curr, role: Number(curr.role) };
      const digits = unmask(curr.cpf);

      if (digits && digits !== originalCpf) out.cpf = digits;
      else delete out.cpf;

      if (!out.data_nascimento) delete out.data_nascimento;
      return out;
    });

    editForm.put(`/users/${editForm.data.id}`, {
      preserveScroll: true,
      onSuccess: () => setEditing(null),
    });
  };

  /* ===== Excluir ===== */
  const [toDelete, setToDelete] = useState(null);

  const confirmDelete = () => {
    if (!toDelete) return;
    editForm.delete(`/users/${toDelete.id}`, {
      preserveScroll: true,
      onFinish: () => setToDelete(null),
    });
  };

  /* ===== Busca (cliente) ===== */
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const s = q.toLowerCase().trim();
    if (!s) return users;
    return users.filter(
      (u) =>
        (u.name || "").toLowerCase().includes(s) ||
        (u.email || "").toLowerCase().includes(s) ||
        (u.cpf || "").toLowerCase().includes(s)
    );
  }, [q, users]);

  return (
    <AuthLayout>
      {/* Container principal */}
      <div
        style={{
          width: "100%",
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "2rem 1rem",
          minHeight: "100vh",
        }}
      >
        {/* Toast */}
        {toast && (
          <Portal>
            <div
              style={{
                position: "fixed",
                top: "20px",
                right: "20px",
                padding: "12px 20px",
                borderRadius: "8px",
                color: "white",
                backgroundColor: toast.type === "ok" ? "#4CAF50" : "#F44336",
                zIndex: 10000,
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
              }}
              role="status"
              aria-live="polite"
            >
              {toast.text}
            </div>
          </Portal>
        )}

        {/* Header */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "2rem",
          }}
        >
          <h1
            style={{
              fontSize: "2.5rem",
              fontWeight: "bold",
              color: "#FFFFFF",
              margin: 0,
            }}
          >
            Usuários
          </h1>
          <div style={{ display: "flex", gap: "12px" }}>
            {canCreate && (
              <Link
                href="/users/create"
                style={{
                  padding: "12px 24px",
                  backgroundColor: "#F9A825",
                  color: "white",
                  textDecoration: "none",
                  borderRadius: "12px",
                  fontWeight: "600",
                  transition: "all 0.2s",
                  border: "none",
                  cursor: "pointer",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.backgroundColor = "#F57F17")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.backgroundColor = "#F9A825")
                }
              >
                Adicionar usuário
              </Link>
            )}
            <Link
              href="/logout"
              method="post"
              as="button"
              style={{
                padding: "12px 24px",
                backgroundColor: "transparent",
                color: "#FFFFFF",
                textDecoration: "none",
                borderRadius: "12px",
                fontWeight: "600",
                border: "2px solid #FFFFFF",
                cursor: "pointer",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = "#FFFFFF";
                e.currentTarget.style.color = "#333";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = "transparent";
                e.currentTarget.style.color = "#FFFFFF";
              }}
            >
              Sair
            </Link>
          </div>
        </div>

        {/* Painel principal */}
        <div
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: "20px",
            padding: "2rem",
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
            minHeight: "700px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* Busca */}
          <div style={{ marginBottom: "1.5rem" }}>
            <input
              style={{
                width: "100%",
                padding: "16px 20px",
                border: "2px solid #E0E0E0",
                borderRadius: "12px",
                fontSize: "1rem",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              placeholder="Buscar por nome, e-mail ou CPF..."
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#F9A825")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "#E0E0E0")}
            />
          </div>

          {/* Lista */}
          <div
            style={{
              flex: 1,
              overflowY: "auto",
              maxHeight: "500px",
              paddingRight: "8px",
            }}
          >
            {filtered.map((u) => (
              <UserRow
                key={u.id}
                u={u}
                onEdit={() => openEdit(u)}
                onDelete={() => setToDelete(u)}
              />
            ))}
            {filtered.length === 0 && (
              <div
                style={{
                  textAlign: "center",
                  color: "#999",
                  padding: "3rem",
                  fontSize: "1.1rem",
                }}
              >
                Nenhum usuário encontrado.
              </div>
            )}
          </div>
        </div>

        {/* MODAL EDITAR */}
        {editing && (
          <Portal>
            <div
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 10000,
              }}
              onClick={() => setEditing(null)}
            >
              <div
                style={{
                  backgroundColor: "white",
                  borderRadius: "16px",
                  padding: "2rem",
                  width: "90%",
                  maxWidth: "500px",
                  maxHeight: "80vh",
                  overflowY: "auto",
                }}
                onClick={(e) => e.stopPropagation()}
              >
                <h3 style={{ marginTop: 0, marginBottom: "1.5rem", fontSize: "1.5rem" }}>
                  Editar usuário
                </h3>

                <form onSubmit={submitEdit}>
                  <div style={{ marginBottom: "1rem" }}>
                    <label style={{ display: "block", marginBottom: ".5rem", fontWeight: 600 }}>
                      Nome
                    </label>
                    <input
                      style={{
                        width: "100%",
                        padding: "12px",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                        fontSize: "1rem",
                      }}
                      value={editForm.data.name}
                      onChange={(e) => editForm.setData("name", e.target.value)}
                      required
                    />
                    {editForm.errors.name && (
                      <small style={{ color: "#F44336" }}>{editForm.errors.name}</small>
                    )}
                  </div>

                  <div style={{ marginBottom: "1rem" }}>
                    <label style={{ display: "block", marginBottom: ".5rem", fontWeight: 600 }}>
                      CPF
                    </label>
                    <input
                      style={{
                        width: "100%",
                        padding: "12px",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                        fontSize: "1rem",
                      }}
                      inputMode="numeric"
                      value={editForm.data.cpf}
                      onChange={(e) => editForm.setData("cpf", maskCpf(e.target.value))}
                      required
                    />
                    {editForm.errors.cpf && (
                      <small style={{ color: "#F44336" }}>{editForm.errors.cpf}</small>
                    )}
                  </div>

                  <div style={{ marginBottom: "1rem" }}>
                    <label style={{ display: "block", marginBottom: ".5rem", fontWeight: 600 }}>
                      E-mail
                    </label>
                    <input
                      style={{
                        width: "100%",
                        padding: "12px",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                        fontSize: "1rem",
                      }}
                      type="email"
                      value={editForm.data.email}
                      onChange={(e) => editForm.setData("email", e.target.value)}
                      required
                    />
                    {editForm.errors.email && (
                      <small style={{ color: "#F44336" }}>{editForm.errors.email}</small>
                    )}
                  </div>

                  <div style={{ marginBottom: "1rem" }}>
                    <label style={{ display: "block", marginBottom: ".5rem", fontWeight: 600 }}>
                      Nível
                    </label>
                    <select
                      style={{
                        width: "100%",
                        padding: "12px",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                        fontSize: "1rem",
                      }}
                      value={editForm.data.role}
                      onChange={(e) => editForm.setData("role", Number(e.target.value))}
                    >
                      <option value={1}>Administrador</option>
                      <option value={2}>Moderador</option>
                      <option value={3}>Leitor</option>
                    </select>
                    {editForm.errors.role && (
                      <small style={{ color: "#F44336" }}>{editForm.errors.role}</small>
                    )}
                  </div>

                  <div style={{ marginBottom: "1rem" }}>
                    <label style={{ display: "block", marginBottom: ".5rem", fontWeight: 600 }}>
                      Nova senha (opcional)
                    </label>
                    <input
                      style={{
                        width: "100%",
                        padding: "12px",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                        fontSize: "1rem",
                      }}
                      type="password"
                      value={editForm.data.password}
                      onChange={(e) => editForm.setData("password", e.target.value)}
                    />
                    {editForm.errors.password && (
                      <small style={{ color: "#F44336" }}>{editForm.errors.password}</small>
                    )}
                  </div>

                  <div style={{ marginBottom: "2rem" }}>
                    <label style={{ display: "block", marginBottom: ".5rem", fontWeight: 600 }}>
                      Confirmar nova senha
                    </label>
                    <input
                      style={{
                        width: "100%",
                        padding: "12px",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                        fontSize: "1rem",
                      }}
                      type="password"
                      value={editForm.data.password_confirmation}
                      onChange={(e) => editForm.setData("password_confirmation", e.target.value)}
                    />
                  </div>

                  <div style={{ display: "flex", gap: "12px", justifyContent: "flex-end" }}>
                    <button
                      type="button"
                      style={{
                        padding: "12px 24px",
                        backgroundColor: "#f5f5f5",
                        color: "#333",
                        border: "none",
                        borderRadius: "8px",
                        cursor: "pointer",
                      }}
                      onClick={() => setEditing(null)}
                    >
                      Cancelar
                    </button>
                    <button
                      style={{
                        padding: "12px 24px",
                        backgroundColor: "#F9A825",
                        color: "white",
                        border: "none",
                        borderRadius: "8px",
                        cursor: "pointer",
                      }}
                      disabled={editForm.processing}
                    >
                      Salvar
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </Portal>
        )}

        {/* MODAL EXCLUIR */}
        {toDelete && (
          <Portal>
            <div
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: "rgba(0,0,0,.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 10000,
              }}
              onClick={() => setToDelete(null)}
            >
              <div
                onClick={(e) => e.stopPropagation()}
                style={{
                  background: "#fff",
                  borderRadius: 16,
                  padding: "2rem",
                  width: "90%",
                  maxWidth: 400,
                }}
              >
                <h3 style={{ marginTop: 0, marginBottom: "1rem", fontSize: "1.25rem" }}>
                  Excluir usuário
                </h3>
                <p style={{ marginBottom: "2rem" }}>
                  Tem certeza que deseja excluir <strong>{toDelete.name}</strong>?
                </p>
                <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
                  <button
                    style={{
                      padding: "12px 24px",
                      background: "#eee",
                      color: "#333",
                      border: "none",
                      borderRadius: 8,
                      cursor: "pointer",
                    }}
                    onClick={() => setToDelete(null)}
                  >
                    Cancelar
                  </button>
                  <button
                    style={{
                      padding: "12px 24px",
                      background: "#F44336",
                      color: "white",
                      border: "none",
                      borderRadius: 8,
                      cursor: "pointer",
                    }}
                    onClick={confirmDelete}
                    disabled={editForm.processing}
                  >
                    Excluir
                  </button>
                </div>
              </div>
            </div>
          </Portal>
        )}
      </div>
    </AuthLayout>
  );
}

/* ---------- Linha de usuário ---------- */
function UserRow({ u, onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0 });
  const btnRef = useRef(null);
  const menuRef = useRef(null); // <-- novo

  // fecha o dropdown só se clicar fora do botão E fora do menu
  useEffect(() => {
    function handleDown(e) {
      const insideBtn = btnRef.current?.contains(e.target);
      const insideMenu = menuRef.current?.contains(e.target);
      if (!insideBtn && !insideMenu) setOpen(false);
    }
    document.addEventListener("mousedown", handleDown);
    return () => document.removeEventListener("mousedown", handleDown);
  }, []);

  const getChipStyle = (role) => {
    switch (role) {
      case 1:
        return { backgroundColor: "#E8F5E9", color: "#2E7D32", border: "1px solid #C8E6C9", fontWeight: 600 };
      case 2:
        return { backgroundColor: "#FFF3E0", color: "#F57C00", border: "1px solid #FFCC02", fontWeight: 600 };
      default:
        return { backgroundColor: "#E3F2FD", color: "#1565C0", border: "1px solid #BBDEFB", fontWeight: 600 };
    }
  };

  const toggleMenu = () => {
    if (!btnRef.current) return;
    const r = btnRef.current.getBoundingClientRect();
    setMenuPos({ top: r.bottom + 8, left: r.right - 160 }); // 160px ≈ largura do menu
    setOpen((v) => !v);
  };

  const canEdit = u?.can?.edit !== false;     // <-- default: pode editar
  const canDelete = u?.can?.delete !== false; // <-- default: pode excluir

  return (
    <div
      style={{
        display: "flex", alignItems: "center", padding: "20px 16px", marginBottom: 8,
        borderRadius: 12, transition: "all .2s ease", backgroundColor: "#FAFAFA",
        border: "1px solid #F0F0F0", position: "relative",
      }}
      onMouseEnter={(e) => {
        const t = e.currentTarget;
        t.style.backgroundColor = "#F5F5F5";
        t.style.borderColor = "#E0E0E0";
        t.style.transform = "translateY(-1px)";
        t.style.boxShadow = "0 4px 12px rgba(0,0,0,.08)";
      }}
      onMouseLeave={(e) => {
        const t = e.currentTarget;
        t.style.backgroundColor = "#FAFAFA";
        t.style.borderColor = "#F0F0F0";
        t.style.transform = "translateY(0)";
        t.style.boxShadow = "none";
      }}
    >
      {/* Esquerda */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, flex: 1, minWidth: 0 }}>
        <div style={{ flexShrink: 0 }}>{avatar}</div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontWeight: 700, color: "#1A1A1A", fontSize: "1.1rem", marginBottom: 4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {u.name}
          </div>
          <div style={{ fontSize: ".95rem", color: "#666", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontWeight: 500 }}>
            {u.email}
          </div>
        </div>
      </div>

      {/* Direita */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, marginLeft: "auto" }}>
        <span style={{ padding: "8px 16px", borderRadius: 20, fontSize: ".85rem", ...getChipStyle(u.role), whiteSpace: "nowrap" }}>
          {roleLabel(u.role)}
        </span>

        {/* Botão + Menu */}
        <div style={{ position: "relative" }} ref={btnRef}>
          <button
            style={{
              padding: "10px 20px", backgroundColor: "#fff", color: "#555", border: "2px solid #E0E0E0",
              borderRadius: 10, cursor: "pointer", fontSize: ".9rem", fontWeight: 600, transition: "all .2s",
              display: "flex", alignItems: "center", gap: 8, boxShadow: "0 2px 4px rgba(0,0,0,.05)",
            }}
            onClick={toggleMenu}
            onMouseEnter={(e) => {
              const b = e.currentTarget;
              b.style.backgroundColor = "#F9A825";
              b.style.color = "#fff";
              b.style.borderColor = "#F9A825";
              b.style.transform = "translateY(-1px)";
              b.style.boxShadow = "0 4px 8px rgba(249,168,37,.3)";
            }}
            onMouseLeave={(e) => {
              const b = e.currentTarget;
              b.style.backgroundColor = "#fff";
              b.style.color = "#555";
              b.style.borderColor = "#E0E0E0";
              b.style.transform = "translateY(0)";
              b.style.boxShadow = "0 2px 4px rgba(0,0,0,.05)";
            }}
          >
            Ações
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 9l6 6 6-6" />
            </svg>
          </button>

          {open && (
            <Portal>
              <div
                ref={menuRef} // <-- importante: para o outside click não fechar antes
                style={{
                  position: "fixed",
                  top: menuPos.top,
                  left: menuPos.left,
                  backgroundColor: "white",
                  border: "1px solid #E0E0E0",
                  borderRadius: 12,
                  boxShadow: "0 12px 24px rgba(0,0,0,.12)",
                  zIndex: 10000,
                  minWidth: 160,
                  overflow: "hidden",
                }}
              >
                <button
                  style={{
                    width: "100%", padding: "14px 18px", border: "none", background: "transparent",
                    textAlign: "left", cursor: canEdit ? "pointer" : "not-allowed",
                    fontSize: ".9rem", fontWeight: 500, color: canEdit ? "#333" : "#999",
                    borderBottom: "1px solid #F0F0F0", opacity: canEdit ? 1 : .6,
                  }}
                  disabled={!canEdit}
                  onClick={() => { setOpen(false); onEdit(); }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#F8F9FA")}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
                >
                  ✏️ Editar
                </button>

                <button
                  style={{
                    width: "100%", padding: "14px 18px", border: "none", background: "transparent",
                    textAlign: "left", cursor: canDelete ? "pointer" : "not-allowed",
                    fontSize: ".9rem", fontWeight: 500, color: canDelete ? "#F44336" : "#999",
                    opacity: canDelete ? 1 : .6,
                  }}
                  disabled={!canDelete}
                  onClick={() => { setOpen(false); onDelete(); }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#FFEBEE")}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
                >
                  🗑️ Excluir
                </button>
              </div>
            </Portal>
          )}
        </div>
      </div>
    </div>
  );
}
